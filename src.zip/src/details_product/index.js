import { render } from "@testing-library/react";
import React from "react";

const Details_product = (props) =>{
    return (
        <div>
        <h2 className="Product_name"></h2>
            <img src={props.imgLink} />
            <p>Description: {props.description}</p>
            {/* <div>Available Stock Number: {stockNum}</div> */}
            <div>Price: {props.price}TL</div>
            {/* <button onClick={handleOnLike}>like</button><div>Likes: {likesNumber}</div>
            <button onClick={handleOnAdd}>Add to Cart</button> */}
        </div>
    )
}

export default Details_product;